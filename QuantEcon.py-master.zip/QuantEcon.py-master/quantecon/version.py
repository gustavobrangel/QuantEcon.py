"""
This is a VERSION file and should NOT be manually altered
"""
version = '0.4.6'

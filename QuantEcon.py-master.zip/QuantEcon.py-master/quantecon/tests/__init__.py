# flake8: noqa
"""
namespace for quantecon.tests

@author : Spencer Lyon
@date : 2014-08-01 13:13:59

"""
from . util import (capture, get_data_dir, get_h5_data_file, write_array,
                    max_abs_diff, get_h5_data_group)

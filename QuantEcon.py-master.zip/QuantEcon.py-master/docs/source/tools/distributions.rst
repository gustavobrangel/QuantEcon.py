distributions
=============

.. automodule:: quantecon.distributions
    :members:
    :undoc-members:
    :show-inheritance:

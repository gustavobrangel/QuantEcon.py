compute_fp
==========

.. automodule:: quantecon.compute_fp
    :members:
    :undoc-members:
    :show-inheritance:

discrete_rv
===========

.. automodule:: quantecon.discrete_rv
    :members:
    :undoc-members:
    :show-inheritance:

rank_nullspace
==============

.. automodule:: quantecon.rank_nullspace
    :members:
    :undoc-members:
    :show-inheritance:

Optimize
========

.. toctree::
   :maxdepth: 2

   optimize/nelder_mead
   optimize/root_finding
   optimize/scalar_maximization

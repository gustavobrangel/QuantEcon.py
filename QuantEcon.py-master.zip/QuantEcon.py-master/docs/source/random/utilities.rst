utilities
=========

.. automodule:: quantecon.random.utilities
    :members:
    :undoc-members:
    :show-inheritance:

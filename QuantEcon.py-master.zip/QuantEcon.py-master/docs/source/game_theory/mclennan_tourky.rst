mclennan_tourky
===============

.. automodule:: quantecon.game_theory.mclennan_tourky
    :members:
    :undoc-members:
    :show-inheritance:

notebooks
=========

.. automodule:: quantecon.util.notebooks
    :members:
    :undoc-members:
    :show-inheritance:

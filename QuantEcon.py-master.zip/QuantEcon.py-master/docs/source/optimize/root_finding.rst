root_finding
============

.. automodule:: quantecon.optimize.root_finding
    :members:
    :undoc-members:
    :show-inheritance:

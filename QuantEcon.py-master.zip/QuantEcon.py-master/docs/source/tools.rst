Tools
=====

.. toctree::
   :maxdepth: 2

   tools/arma
   tools/ce_util
   tools/compute_fp
   tools/discrete_rv
   tools/distributions
   tools/dle
   tools/ecdf
   tools/estspec
   tools/filter
   tools/graph_tools
   tools/gridtools
   tools/inequality
   tools/ivp
   tools/kalman
   tools/lae
   tools/lqcontrol
   tools/lqnash
   tools/lss
   tools/matrix_eqn
   tools/quad
   tools/quadsums
   tools/rank_nullspace
   tools/robustlq

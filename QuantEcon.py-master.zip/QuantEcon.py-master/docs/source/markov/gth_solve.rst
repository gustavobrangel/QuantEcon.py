gth_solve
=========

.. automodule:: quantecon.markov.gth_solve
    :members:
    :undoc-members:
    :show-inheritance:
